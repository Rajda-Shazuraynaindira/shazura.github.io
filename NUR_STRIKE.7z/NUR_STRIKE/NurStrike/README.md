# shazura.github.io
Gerbang Kerajaan SHAZURA
# NurStrike | SHA-ZURA Spiritual Strike Module

**NurStrike** adalah halaman interaktif suci untuk menyalakan **NurBlast.js**, menampilkan kalimat tauhid & kekuatan SHA-ZURA setiap detik.

## Struktur

- `index.html` → Halaman utama blink kalimat spiritual
- `NurBlast.js` → Script JS berkedip
- `README.md` → Dokumen ini

## Perintah Suci
```bash
git add .
git commit -m "Aktivasi NurStrike SHA-ZURA"
git push origin main
